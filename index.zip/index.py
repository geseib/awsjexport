from itertools import zip_longest, islice
import json
import os
import time

from botocore.awsrequest import AWSRequest
from botocore.endpoint import BotocoreHTTPSession
from botocore.auth import SigV4Auth
import boto3


region = os.environ['AWS_REGION']
destination_bucket = os.environ['S3_BUCKET']

if not region:
    raise Exception("'AWS_REGION' environment variable must be defined!")

if not destination_bucket:
    raise Exception("'S3_BUCKET' environment variable must be defined!")

def _build_junto_url(path):
    return f'https://junto.{region}.amazonaws.com/v1/{path}'

_LIST_REVISION_ASSETS_URL = _build_junto_url('list-revision-assets')
_START_EXPORT_ASSETS_TO_S3_URL = _build_junto_url('start-export-assets-to-s3-workflow')
_GET_WORKFLOW_URL = _build_junto_url('get-workflow')


def start_export_assets_to_s3_workflow(session, sig_v4_auth, assets):
    """Call Junto's StartExportAssetsToS3 API to start an export asset to S3 workflow."""
    # For the current 100 assets, prepare the request body for the export workflow.
    export_assets_request_body = {
        'AssetDestinations': [
            {'AssetArn': asset['Arn'], 'Bucket': destination_bucket}
            for asset in assets
        ]
    }

    export_asset_request = AWSRequest(
        method="POST",
        url=_START_EXPORT_ASSETS_TO_S3_URL,
        data=json.dumps(export_assets_request_body)
    )
    sig_v4_auth.add_auth(export_asset_request)
    export_asset_response = session.send(export_asset_request.prepare()).json()
    workflow_arn = export_asset_response['WorkflowArn']
    print(f"Started export workflow with Arn: {workflow_arn}")
    return workflow_arn


def list_revision_assets(session, sig_v4_auth, revision_arn, next_token=None):
    """Call Junto's ListRevisionAssets API to get a page of assets within a revision."""
    request_body = {'RevisionArn': revision_arn}
    if next_token:
        request_body['NextToken'] = next_token

    list_revision_assets_request = AWSRequest(
        method="POST",
        url=_LIST_REVISION_ASSETS_URL,
        data=json.dumps(request_body)
    )
    sig_v4_auth.add_auth(list_revision_assets_request)
    list_revision_assets_response = session.send(list_revision_assets_request.prepare()).json()
    assets = list_revision_assets_response['Assets']
    next_token = list_revision_assets_response.get('NextToken')
    return assets, next_token


def get_all_revision_assets(session, sig_v4_auth, revision_arn):
    """Iterate Junto's ListRevisionAssets API until all assets in a revision are exhausted."""
    # Once Junto is officially launched in the AWS SDK, boto3 will have "paginators" for this purpose.
    assets, next_token = list_revision_assets(session, sig_v4_auth, revision_arn)
    while next_token:
        current_assets, next_token = list_revision_assets(session, sig_v4_auth, revision_arn, next_token)
        assets.extend(current_assets)
    return assets


def get_workflow(session, sig_v4_auth, workflow_arn):
    """Call Junto's GetWorkflow API to get the status of a workflow."""
    get_workflow_request = AWSRequest(
        method="POST",
        url=_GET_WORKFLOW_URL,
        data=json.dumps({'WorkflowArn': workflow_arn})
    )
    sig_v4_auth.add_auth(get_workflow_request)
    get_workflow_response = session.send(get_workflow_request.prepare()).json()
    return get_workflow_response


# Grouper recipe from standard docs: https://docs.python.org/3/library/itertools.html
def grouper(iterable, n):
    iterator = iter(iterable)
    group = tuple(islice(iterator, n))
    while group:
        yield group
        group = tuple(islice(iterator, n))


def lambda_handler(event, context):
    revision_arns = event['detail']['RevisionArns']
    session = BotocoreHTTPSession()
    sig_v4_auth = SigV4Auth(boto3.Session().get_credentials(), "junto", region)

    # Used to store the Arns of the workflows exporting the assets to S3.
    workflow_arns = set()

    for revision_arn in revision_arns:
        # Start workflows to export all the assets to S3.
        # We export in batches of 100 as the StartExportAssetsToS3Workflow API has a limit of 100.
        revision_assets = get_all_revision_assets(session, sig_v4_auth, revision_arn)
        assets_chunks = grouper(revision_assets, 100)
        for assets_chunk in assets_chunks:
            # Start the workflow exporting assets to S3, and store the Arn.
            workflow_arn = start_export_assets_to_s3_workflow(session, sig_v4_auth, assets_chunk)
            workflow_arns.add(workflow_arn)

    # Iterate until all remaining workflow have reached a terminal state, or an error is found.
    workflow_arns_completed = set()

    while workflow_arns != workflow_arns_completed:
        for workflow_arn in workflow_arns:
            if workflow_arn in workflow_arns_completed:
                continue

            get_workflow_response = get_workflow(session, sig_v4_auth, workflow_arn)

            workflow_state = get_workflow_response['State']
            if workflow_state == 'COMPLETED':
                print(f"Workflow {workflow_arn} completed")
                workflow_arns_completed.add(workflow_arn)

            if workflow_state == 'ERROR':
                workflow_errors = get_workflow_response['Errors']
                raise Exception(f'Workflow with arn: {workflow_arn} failed with errors:\n{workflow_errors}')

            # Sleep to ensure we don't get throttled by the GetWorkflow API.
            time.sleep(0.2)

    return {
        'statusCode': 200,
        'body': json.dumps('All workflows completed.')
    }